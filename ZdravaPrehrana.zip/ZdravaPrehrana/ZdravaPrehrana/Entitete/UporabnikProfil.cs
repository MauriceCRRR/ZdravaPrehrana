using System;

public class UporabnikProfil {
	private double visina;
	private double teza;
	private List<String> alergije;
	private List<String> omejitve;

	public bool UrediProfil(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void DodajAlergijo(ref String alergija) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void DodajOmejitev(ref String omejitev) {
		throw new System.NotImplementedException("Not implemented");
	}

	private Uporabnik imaProfil;

}
