using System;

public class VnosHranil {
	private DateTime datum;
	private int kalorije;
	private double beljakovine;
	private double mascobe;
	private double ogljikoviHidrati;

	public bool DodajVnos(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PridobiVrednosti() {
		throw new System.NotImplementedException("Not implemented");
	}

	private UpravljalecCiljev spremljaVnos;

	private Uporabnik vnese;
	private UpravljalecHranil upravljaVnos;

}
