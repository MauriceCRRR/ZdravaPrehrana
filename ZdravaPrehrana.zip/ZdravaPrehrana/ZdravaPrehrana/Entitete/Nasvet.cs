using System;

public class Nasvet {
	private string vsebina;
	private DateTime datum;
	private string status;

	public bool UstvariNasvet(ref string vsebina) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PotrdiNasvet() {
		throw new System.NotImplementedException("Not implemented");
	}

	private Uporabnik pridobiNasvet;
	private UpravljalecNasvetov upravljaNasvet;

}
