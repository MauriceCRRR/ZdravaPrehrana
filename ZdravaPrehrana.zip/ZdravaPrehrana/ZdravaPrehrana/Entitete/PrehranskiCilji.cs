using System;

public class PrehranskiCilji {
	private double ciljnaTeza;
	private int casovniOkvir;
	private int dnevneKalorije;

	public bool NastaviCilj(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public double PreveriNapredek() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PosodobiCilj(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}

	private UpravljalecCiljev upravljaCilj;

	private Uporabnik ustvariCilj;

}
