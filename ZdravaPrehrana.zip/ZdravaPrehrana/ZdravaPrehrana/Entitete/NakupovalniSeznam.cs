using System;

public class NakupovalniSeznam {
	private string naziv;
	private List<String> sestavine;
	private List<double> kolicine;

	public void DodajSestavino(ref string sestavina) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void OdstraniSestavino(ref string sestavina) {
		throw new System.NotImplementedException("Not implemented");
	}

	private UpravljalecNakupovanja upravljaSeznam;

	private Uporabnik ustvariSeznam;

}
