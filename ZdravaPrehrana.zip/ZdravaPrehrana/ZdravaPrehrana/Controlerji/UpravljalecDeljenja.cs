using System;

public class UpravljalecDeljenja {
	public bool DeliVsebino(ref Object vsebina, ref Uporabnik prejemnik) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PreveriDostop(ref Uporabnik uporabnik) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PosljiPovabilo(ref string email) {
		throw new System.NotImplementedException("Not implemented");
	}

	private Uporabnik[] deliVsebinoZ;

}
