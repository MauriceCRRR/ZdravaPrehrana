using System;

public class UpravljalecCiljev {
	public bool NastaviCilje(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public double SpremljajNapredek() {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PosodobiCilje(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PreveriDoseganjeCiljev() {
		throw new System.NotImplementedException("Not implemented");
	}

	private PrehranskiCilji upravljaCilj;
	private VnosHranil[] spremljaVnos;

}
