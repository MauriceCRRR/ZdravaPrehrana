using System;
using ZdravaPrehrana.Entitete;
public class UpravljalecHranil {
	public bool DodajVnosHranil(ref object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PreveriVnos(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public double IzracunHranilneVrednosti() {
		throw new System.NotImplementedException("Not implemented");
	}
	public VnosHranil PridobiDnevniVnos(ref DateTime datum) {
		throw new System.NotImplementedException("Not implemented");
	}

	private VnosHranil[] upravljaVnos;

}
