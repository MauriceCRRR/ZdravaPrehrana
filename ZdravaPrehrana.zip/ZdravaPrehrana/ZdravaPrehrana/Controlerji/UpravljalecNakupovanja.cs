using System;

public class UpravljalecNakupovanja {
	public NakupovalniSeznam KreirajSeznam() {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool DodajIzdelke(ref NakupovalniSeznam seznam, ref List<String> izdelki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool OdstraniIzdelek(ref NakupovalniSeznam seznam, ref string izdelki) {
		throw new System.NotImplementedException("Not implemented");
	}

	private NakupovalniSeznam[] upravljaSeznam;

}
