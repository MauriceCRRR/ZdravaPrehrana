using System;
using System.Collections.Generic;
using ZdravaPrehrana.Entitete;

public class UpravljalecFeedbacka {
	public bool DodajFeedback(ref int receptId, ref int ocena, ref string komentar) {
		throw new System.NotImplementedException("Not implemented");
	}
	public List<Ocena> PridobiOcene(ref int receptId) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PreveriUstreznost(ref string komentar) {
		throw new System.NotImplementedException("Not implemented");
	}

	private Feedback[] upravljaFeedback;
	private Uporabnik prejmeOd;

}
