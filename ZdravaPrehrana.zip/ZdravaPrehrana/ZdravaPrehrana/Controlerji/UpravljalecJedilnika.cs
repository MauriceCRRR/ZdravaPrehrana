using System;

public class UpravljalecJedilnika {
	private Jedilnik aktivniJedilnik;

	public Jedilnik KreirajJedilnik(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool ShraniJedilnik(ref Jedilnik jedilnik) {
		throw new System.NotImplementedException("Not implemented");
	}
	public Jedilnik PridobiJedilnik(ref int id) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PreveriSkladnostCiljev(ref Jedilnik jedilnik) {
		throw new System.NotImplementedException("Not implemented");
	}

	private Jedilnik[] upravlja;

}
