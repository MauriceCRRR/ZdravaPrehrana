using System;

public class UpravljalecNasvetov {
	public Nasvet GenerirajNasvet(ref Object podatki) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool ShraniNasvet(ref Nasvet nasvet) {
		throw new System.NotImplementedException("Not implemented");
	}
	public bool PosredujStrokovnjaku(ref Nasvet nasvet) {
		throw new System.NotImplementedException("Not implemented");
	}
	public List<Nasvet> PridobiNasvete() {
		throw new System.NotImplementedException("Not implemented");
	}

	private Nasvet[] upravljaNasvet;

	private Uporabnik gemeriraZa;

}
