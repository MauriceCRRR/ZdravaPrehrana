using System;
namespace ZdravaPrehrana.Boundary
{
	public class NakupovalniSeznamOkno
	{
		public void PrikaziSeznam(ref NakupovalniSeznam seznam)
		{
			throw new System.NotImplementedException("Not implemented");
		}
		public void PrikaziObrazecZaDodajanje()
		{
			throw new System.NotImplementedException("Not implemented");
		}
		public void OznaciKupljeno(ref string izdelek)
		{
			throw new System.NotImplementedException("Not implemented");
		}
		public void PrikaziPotrditev()
		{
			throw new System.NotImplementedException("Not implemented");
		}

		private GlavnoOkno odpreNakupovalniSeznamOkno;

	}
}
