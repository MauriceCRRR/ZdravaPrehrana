using System;


namespace ZdravaPrehrana.Boundary
{
    public class CiljiOkno {
	public void PrikaziCilje(ref PrehranskiCilji cilji) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziObrazecZaNastavitev() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziNapredek(ref double napredek) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziOpozorilo(ref string sporocilo) {
		throw new System.NotImplementedException("Not implemented");
	}

	private GlavnoOkno odpreCiljiOkno;

}
}
