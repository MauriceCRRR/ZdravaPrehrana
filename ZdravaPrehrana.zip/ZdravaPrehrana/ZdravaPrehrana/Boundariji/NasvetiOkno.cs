using System;


namespace ZdravaPrehrana.Boundary
{
    public class NasvetiOkno {
	public void PrikaziNasvet(ref Nasvet nasvet) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziOdziv(ref string odziv) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziZgodovinoNasvetov() {
		throw new System.NotImplementedException("Not implemented");
	}

	private GlavnoOkno odpreNasvetiOkno;

}
}
