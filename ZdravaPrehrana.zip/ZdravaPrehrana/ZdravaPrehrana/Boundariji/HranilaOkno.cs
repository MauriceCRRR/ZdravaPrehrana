using System;


namespace ZdravaPrehrana.Boundary
{
    public class HranilaOkno {
	public void PrikaziVnosHranil() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziDnevniPregled(ref DateTime datum) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziStatistiko() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziNapako(ref string sporocilo) {
		throw new System.NotImplementedException("Not implemented");
	}

	private GlavnoOkno odpreHranilaOkno;

  }
}

