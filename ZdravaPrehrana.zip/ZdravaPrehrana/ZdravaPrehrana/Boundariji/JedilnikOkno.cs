using System;


namespace ZdravaPrehrana.Boundary {
public class JedilnikOkno {
	public void PrikaziJedilnik(ref Jedilnik jedilnik) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziObrazecZaUrejanje() {
		throw new System.NotImplementedException("Not implemented");
	}
	public void PrikaziSporocilo(ref string sporocilo) {
		throw new System.NotImplementedException("Not implemented");
	}
	public void OsveziPrikaz() {
		throw new System.NotImplementedException("Not implemented");
	}

	private GlavnoOkno odpreJedilnikOkno;

}
} 
